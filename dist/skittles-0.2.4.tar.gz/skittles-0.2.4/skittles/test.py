def rainbow():
    print("I like Skittles.")